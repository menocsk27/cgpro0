// dummmy conio.h for bgidemo.c

// empty!
